"use client";

import { useMemo, useState } from "react";
import {
  Activity, Bell, Bookmark, ChartCandlestick, ChevronDown, CircleHelp, Compass,
  Globe2, Hash, Home, Languages, MessageCircle, Plus, Search, Settings, ShieldCheck,
  TrendingUp, Users, WalletCards, X, Menu
} from "lucide-react";

type Lang = "en" | "ar" | "fr";
type Post = { id: number; name: string; handle: string; time: string; symbol: string; side: "BUY" | "SELL"; body: string; likes: number; comments: number; avatar: string };

const copy = {
  en: { home:"Home", explore:"Explore", markets:"Markets", community:"Community", messages:"Messages", saved:"Saved", title:"Your trading community.", subtitle:"Ideas move markets. Share yours.", feed:"Community feed", latest:"Latest", popular:"Popular", following:"Following", compose:"Share an idea, chart or market insight...", publish:"Publish post", market:"Market pulse", movers:"Top movers", online:"Traders online", welcome:"Good afternoon", view:"View all", join:"Join the conversation", disclaimer:"Trading involves risk. Ideas shared by members are educational, not financial advice." },
  ar: { home:"الرئيسية", explore:"استكشف", markets:"الأسواق", community:"المجتمع", messages:"الرسائل", saved:"المحفوظات", title:"مجتمع المتداولين.", subtitle:"الأفكار تحرك الأسواق. شارك أفكارك.", feed:"منشورات المجتمع", latest:"الأحدث", popular:"الأكثر تفاعلاً", following:"أتابعهم", compose:"شارك فكرة أو رسماً بيانياً أو تحليلاً للسوق...", publish:"نشر المنشور", market:"نبض السوق", movers:"الأكثر حركة", online:"متداولون متصلون", welcome:"مساء الخير", view:"عرض الكل", join:"شارك في النقاش", disclaimer:"التداول ينطوي على مخاطر. منشورات الأعضاء تعليمية وليست نصيحة مالية." },
  fr: { home:"Accueil", explore:"Explorer", markets:"Marchés", community:"Communauté", messages:"Messages", saved:"Enregistrés", title:"Votre communauté de trading.", subtitle:"Les idées font bouger les marchés. Partagez les vôtres.", feed:"Fil communautaire", latest:"Récent", popular:"Populaire", following:"Abonnements", compose:"Partagez une idée, un graphique ou une analyse...", publish:"Publier", market:"Marché en direct", movers:"Meilleures variations", online:"Traders en ligne", welcome:"Bonsoir", view:"Tout voir", join:"Rejoindre la discussion", disclaimer:"Le trading comporte des risques. Les publications sont éducatives, pas des conseils financiers." }
};

const initialPosts: Post[] = [
  { id:1, name:"Adam Brooks", handle:"@adamb.trades", time:"12 min", symbol:"XAUUSD", side:"BUY", body:"Gold is holding above the intraday demand zone. Watching for a clean retest before considering continuation. Patience over prediction.", likes:28, comments:9, avatar:"AB" },
  { id:2, name:"Sarah Chen", handle:"@sarah.fx", time:"38 min", symbol:"EURUSD", side:"SELL", body:"London session gave us a clear rejection from resistance. Waiting for confirmation on the lower timeframe — no entry until structure agrees.", likes:19, comments:6, avatar:"SC" },
  { id:3, name:"Youssef El Amrani", handle:"@youssef.market", time:"1 h", symbol:"BTCUSD", side:"BUY", body:"A useful reminder: protect capital first. A missed trade costs nothing; a forced trade can cost a lot.", likes:42, comments:14, avatar:"YE" }
];

const marketRows = [
  { symbol:"XAUUSD", name:"Gold / US Dollar", price:"2,684.20", change:"+0.82%", up:true },
  { symbol:"EURUSD", name:"Euro / US Dollar", price:"1.04862", change:"−0.21%", up:false },
  { symbol:"GBPUSD", name:"Pound / US Dollar", price:"1.25740", change:"+0.14%", up:true },
  { symbol:"BTCUSD", name:"Bitcoin", price:"97,420.00", change:"+1.36%", up:true }
];

export default function Dashboard() {
  const [lang, setLang] = useState<Lang>("en");
  const [posts, setPosts] = useState(initialPosts);
  const [draft, setDraft] = useState("");
  const [active, setActive] = useState("home");
  const [mobileOpen, setMobileOpen] = useState(false);
  const t = copy[lang];
  const rtl = lang === "ar";
  const direction = rtl ? "rtl" : "ltr";
  const nav = useMemo(() => [
    { id:"home", label:t.home, icon:Home }, { id:"explore", label:t.explore, icon:Compass },
    { id:"markets", label:t.markets, icon:ChartCandlestick }, { id:"community", label:t.community, icon:Users },
    { id:"messages", label:t.messages, icon:MessageCircle }, { id:"saved", label:t.saved, icon:Bookmark }
  ], [t]);

  function publish() {
    if (!draft.trim()) return;
    setPosts([{ id:Date.now(), name:"Your profile", handle:"@you", time:"now", symbol:"GENERAL", side:"BUY", body:draft.trim(), likes:0, comments:0, avatar:"YO" }, ...posts]);
    setDraft("");
  }

  return (
    <main className="min-h-screen bg-ink text-white" dir={direction}>
      <header className="topbar">
        <button className="mobile-menu icon-btn" onClick={() => setMobileOpen(!mobileOpen)} aria-label="Toggle menu"><Menu size={19}/></button>
        <a className="brand" href="#"><span className="brand-mark"><Activity size={20}/></span><span>FADIL FX</span></a>
        <div className="searchbox"><Search size={17}/><input placeholder={lang==="ar"?"ابحث عن متداول أو سوق أو فكرة":"Search traders, markets, ideas..."}/><kbd>⌘ K</kbd></div>
        <div className="top-actions">
          <button className="language-btn" onClick={() => setLang(lang==="en"?"ar":lang==="ar"?"fr":"en")}><Globe2 size={16}/><span>{lang.toUpperCase()}</span><ChevronDown size={14}/></button>
          <button className="icon-btn notification" aria-label="Notifications"><Bell size={18}/><i/></button>
          <button className="avatar user-avatar">YO</button>
          <button className="login-btn">Sign in</button>
          <button className="signup-btn">Create account</button>
        </div>
      </header>

      <div className="layout">
        <aside className={`sidebar ${mobileOpen?"open":""}`}>
          <div className="profile-mini"><div className="avatar big">G</div><div><strong>Guest trader</strong><span>Explore the community</span></div></div>
          <div className="side-label">WORKSPACE</div>
          <nav>{nav.map(item => { const Icon=item.icon; return <button key={item.id} onClick={() => {setActive(item.id);setMobileOpen(false)}} className={`nav-item ${active===item.id?"active":""}`}><Icon size={18}/><span>{item.label}</span>{item.id==="messages"&&<b>3</b>}</button> })}</nav>
          <div className="side-label groups-label">YOUR MARKETS</div>
          <button className="market-link"><span className="dot gold"/> Gold <small>XAUUSD</small></button>
          <button className="market-link"><span className="dot blue"/> Forex <small>FX</small></button>
          <button className="market-link"><span className="dot violet"/> Crypto <small>BTC</small></button>
          <button className="add-market"><Plus size={15}/> Add market</button>
          <div className="sidebar-bottom"><div className="upgrade-card"><div className="upgrade-icon"><ShieldCheck size={17}/></div><strong>Grow with confidence</strong><p>Learn from the community. Trade with a plan.</p><button>Explore guides <span>→</span></button></div><button className="nav-item"><Settings size={17}/><span>Settings</span></button><button className="nav-item"><CircleHelp size={17}/><span>Help center</span></button></div>
        </aside>

        <section className="feed-column">
          <div className="welcome-row"><div><div className="eyebrow">{t.welcome} <span>✦</span></div><h1>{t.title}</h1><p>{t.subtitle}</p></div><div className="date-pill"><span className="live-dot"/> MARKET OPEN</div></div>
          <div className="feed-tabs"><div className="feed-heading"><h2>{t.feed}</h2><span className="count-pill">{posts.length} posts</span></div><div className="tabs"><button className="selected">{t.latest}</button><button>{t.popular}</button><button>{t.following}</button></div></div>
          <div className="composer card"><div className="avatar">YO</div><div className="composer-main"><textarea value={draft} onChange={e=>setDraft(e.target.value)} placeholder={t.compose}/><div className="composer-footer"><div className="composer-tools"><button><ChartCandlestick size={16}/> Chart</button><button><Hash size={16}/> Topic</button></div><button className="publish-btn" onClick={publish}>{t.publish}<span>↗</span></button></div></div></div>
          <div className="posts">{posts.map(post=><article className="post card" key={post.id}><div className="post-head"><div className="avatar">{post.avatar}</div><div className="post-author"><strong>{post.name}<span className="verified">✓</span></strong><small>{post.handle} · {post.time}</small></div><button className="more">···</button></div><div className="post-body">{post.body}</div><div className="trade-tag"><span className="tag-symbol">{post.symbol}</span><span className={post.side==="BUY"?"buy":"sell"}>{post.side}</span><span className="tag-muted">Market idea</span></div><div className="post-chart"><div className="chart-meta"><span>Intraday structure</span><span>15m <ChevronDown size={12}/></span></div><div className="chart-visual"><div className="chart-grid"/><svg viewBox="0 0 640 120" preserveAspectRatio="none" aria-label="Decorative market chart"><defs><linearGradient id={`fill${post.id}`} x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stopColor="#35D69A" stopOpacity=".22"/><stop offset="100%" stopColor="#35D69A" stopOpacity="0"/></linearGradient></defs><path d="M0 92 C25 88 28 72 55 78 S90 60 115 70 S145 48 170 57 S200 82 225 64 S255 55 280 61 S310 32 335 45 S365 63 390 48 S420 20 445 36 S475 58 500 35 S530 28 555 32 S600 12 640 18 L640 120 L0 120 Z" fill={`url(#fill${post.id})`}/><path d="M0 92 C25 88 28 72 55 78 S90 60 115 70 S145 48 170 57 S200 82 225 64 S255 55 280 61 S310 32 335 45 S365 63 390 48 S420 20 445 36 S475 58 500 35 S530 28 555 32 S600 12 640 18" fill="none" stroke="#35D69A" strokeWidth="2.2"/></svg></div></div><div className="post-actions"><button>♡ <span>{post.likes}</span></button><button><MessageCircle size={16}/> <span>{post.comments}</span></button><button><Bookmark size={16}/> Save</button><button className="share">Share ↗</button></div></article>)}</div>
          <p className="disclaimer">{t.disclaimer}</p>
        </section>

        <aside className="right-column">
          <div className="right-card card"><div className="card-title"><div><span className="eyebrow">LIVE OVERVIEW</span><h3>{t.market}</h3></div><span className="live-label"><i/> LIVE</span></div><div className="market-total"><strong>Markets watch</strong><span>Sample data</span></div>{marketRows.map(row=><div className="market-row" key={row.symbol}><div><strong>{row.symbol}</strong><small>{row.name}</small></div><div className="market-price"><strong>{row.price}</strong><span className={row.up?"positive":"negative"}>{row.change}</span></div></div>)}<button className="view-all">{t.view} markets <span>→</span></button></div>
          <div className="right-card card"><div className="card-title"><div><span className="eyebrow">COMMUNITY</span><h3>{t.online}</h3></div><span className="online-count"><i/> 128</span></div>{[{n:"Maya Williams",h:"@maya.fx",a:"MW",s:"Gold specialist"},{n:"Omar Haddad",h:"@omar.trades",a:"OH",s:"Price action"},{n:"Lucas Martin",h:"@lucas.crypto",a:"LM",s:"Crypto analyst"}].map(p=><div className="trader-row" key={p.h}><div className="avatar small">{p.a}</div><div><strong>{p.n}</strong><small>{p.s}</small></div><button>Follow</button></div>)}<button className="view-all">{t.view} traders <span>→</span></button></div>
          <div className="right-note"><div className="note-icon"><ShieldCheck size={17}/></div><div><strong>Trade responsibly</strong><p>Build knowledge, share ideas and respect risk. No signal guarantees a result.</p></div></div>
          <footer className="mini-footer">About · Guidelines · Privacy · Terms<br/>© 2026 FADIL FX</footer>
        </aside>
      </div>
      <div className="mobile-bottom"><button><Home size={18}/><span>Home</span></button><button><Compass size={18}/><span>Explore</span></button><button><Plus size={21}/><span>Post</span></button><button><MessageCircle size={18}/><span>Chat</span></button><button><WalletCards size={18}/><span>Profile</span></button></div>
    </main>
  );
}
