import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "FADIL FX — Trade. Learn. Grow.",
  description: "A global community for traders to share ideas, learn and grow."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
