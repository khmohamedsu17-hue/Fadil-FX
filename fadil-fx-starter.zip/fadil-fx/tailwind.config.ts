import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./app/**/*.{js,ts,jsx,tsx,mdx}", "./components/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: { extend: { colors: { ink: "#090D0C", panel: "#111816", line: "#24312C", mint: "#35D69A" } } },
  plugins: []
};
export default config;
