# FADIL FX

A custom-built social trading community starter using Next.js, TypeScript, Tailwind CSS and Supabase.

## Included in this first build
- Responsive dark trading-community dashboard
- English, Arabic and French interface switcher (starter UI labels)
- Community feed with a local demo post composer
- Sample market watchlist and trader cards
- Supabase PostgreSQL schema with Row Level Security for profiles, posts, likes, comments and follows

## Requirements
- Node.js 20.9 or newer
- npm
- A Supabase project (free tier is enough to start)

## Run locally
```bash
npm install
npm run dev
```
Open http://localhost:3000

## Connect Supabase
1. Create a project at https://supabase.com
2. Copy `.env.example` to `.env.local`
3. Add your Supabase Project URL and anon/publishable key.
4. Open Supabase SQL Editor and run `supabase/schema.sql`.

The current dashboard is a front-end prototype: demo market prices and sample trader posts are illustrative only. The composer currently adds posts in local browser state. Authentication, persistent posting, real-time chat, live market data, moderation and production hardening are the next development milestones.

## Important
- Never put a Supabase service-role key in browser/client code.
- Add rate limits, spam protection, email verification and moderation before public launch.
- Do not present community ideas as guaranteed trading signals or financial advice.
